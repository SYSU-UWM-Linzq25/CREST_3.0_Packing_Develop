function intercept(this,optBlowSnow,optDrip,TAir,LAI,snowfall,rainfall)
%% writen by Shen, Xinyi, April, 2015
% contact: xinyi.shen@uconn.edu
%% Algorithm Description
% calculate the mass(snow/rainfall) flux caused by canopy interception and
% update the storage accordingly,this.intSnow, this.W
% this function should be called before solving the energy balances at every time step
%% output
% throughRainfall: rainfall through the canopy
% throughSnowfall: snow fall through the canopy
%% input arguments
% optBlowSnow : true, blow the newly fallen snow
%
% LAI: leaf area index
%
% snowfall (mm): accumulated snow fall during the current time step, i.e., total snow fall
%
% rainfall (mm): accumulated snow fall during the current time step, i.e., total rainfall
%% main routine
if isempty(LAI)
    LAI=[];TAir=[];snowfall=[];rainfall=[];
end
global LAI_SNOW_MULTIPLIER MIN_SWQ_EB_THRES SMALL LIQUID_WATER_CAPACITY
%% Determine the maximum snow interception water equivalent           
% Kobayashi, D., 1986, Snow Accumulation on a Narrow Board,           
% Cold Regions Science and Technology, (13), pp. 239-245.           
% Figure 4.
%% store the intercepted water and ice of the last time step
this.WOrg=this.W;
this.intSnowOrg=this.intSnow;
Imax1 = 4.0* LAI_SNOW_MULTIPLIER * LAI;
isCold=this.TSurf<=-3;
maxSnowInt=4*(this.TSurf>=-1)+(isCold)+(this.TSurf*1.5+5.5).*((this.TSurf<1)&(~isCold));
maxSnowInt=LAI_SNOW_MULTIPLIER*maxSnowInt.*LAI;
%% CREST added, if the current intercepted snow exceeds the
if optDrip
    dSnowfall=max(0,this.intSnow-maxSnowInt);
    this.intSnow=this.intSnow-dSnowfall;
    snowfall=snowfall+dSnowfall;
end
%% Calculate snow interception
dSnowInt=snowfall.*(1-this.intSnow./maxSnowInt);
dSnowInt=min(maxSnowInt-this.intSnow,dSnowInt);
dSnowInt(maxSnowInt<=0)=0;
%% Reduce the amount of intercepted snow if windy and cold.         
% Ringyo Shikenjo Tokyo, #54, 1952.                                
% Bulletin of the Govt. Forest Exp. Station,                       
% Govt. Forest Exp. Station, Meguro, Tokyo, Japan.                 
% FORSTX 634.9072 R475r #54.                                       
% Page 146, Figure 10.                                               
% Reduce the amount of intercepted snow if snowing, windy, and     
% cold (< -3 to -5 C).                                             
% Schmidt and Troendle 1992 western snow conference paper.
if optBlowSnow
    snowBlown=(dSnowInt>0)& (dSnowInt>0)& isCold;
    blownSnow = min(1,0.2 * this.UAdj(snowBlown) - 0.2).* dSnowInt(snowBlown);
    dSnowInt(snowBlown)=dSnowInt(snowBlown)-blownSnow;
end
if ~optDrip
    this.snowThru=snowfall-dSnowInt;
else
    this.snowDrip=snowfall-dSnowInt;
end
%% At this point, we have calculated the $$\DELTA SNOW$
[this.intSnow,TSurfNew]=MixWater([this.intSnow,dSnowInt],[this.TSurf,TAir]);
%% At this point, we updated the intercepted snow depth and calculted the new surface temperatures
% this.snowThru(TAir), dSnowInt(TAir)
%% To avoid sovling EB on the canopy with ignorable snow, let them fall through
isThin=(this.intSnow<MIN_SWQ_EB_THRES);
if this.nCells>0
    thinSnow=zeros(this.nCells,1);
else
    thinSnow=[];
end
thinSnow(isThin)=this.intSnow(isThin);
this.intSnow(isThin)=0;
if ~optDrip
    [this.snowThru,this.TThruSnow]=...
        MixWater([this.snowDrip,this.snowThru,thinSnow],[this.TSurf,TAir,TSurfNew]);
else
    this.snowDrip=this.snowDrip+thinSnow;
end
% at this point we have mixed different sources of snow through fall
%% capacity of rain interception on branches and stored in intercepted snow
if isempty(this.intSnow)
    maxWaterInt=[];
else
    maxWaterInt = LIQUID_WATER_CAPACITY*this.intSnow + this.Wm;
end
% if dW<0, excessive water is added to the thru fall
% otherwise, some rainfall is used to fill the interception capacity.
dW=min(maxWaterInt-this.W,rainfall);
increW=dW>=0;
if ~optDrip
    % update the intercepted liquid water
    [this.W,this.TW]=MixWater([this.W,dW.*increW],[this.TSurf,TAir]);
    this.W(~increW)=this.W(~increW)+dW(~increW);
    % update the through fall
    [this.WThru(~increW),this.TWThru(~increW)]=...
        MixWater([this.rainDrip(~increW)-dW(~increW),rainfall(~increW)],...
        [this.TSurf(~increW),TAir(~increW)]);
    [this.WThru(increW),this.TWThru(increW)]=...
        MixWater([this.rainDrip(increW),rainfall(increW)-dW(increW)],...
        [this.TSurf(increW),TAir(increW)]);
else
    this.rainDrip=rainfall-dW;
end
% at these point, both intercepted and thru fall liquid water have been updated
%% update the surface Temperature of the canopy
this.TSurf=TSurfNew;
%% deplete small water amount
this.CleanSmallWater();
% isThin=(this.W<MIN_SWQ_EB_THRES)&(rainfall==0);
% if ~optDrip
%     this.WThru(isThin)=this.WThru(isThin)+this.W(isThin);
% else
%     this.rainDrip(isThin)=this.rainDrip(isThin)+this.W(isThin);
% end
% this.W(isThin)=0;

%% triger unloading if overload
% totalWater=this.W+this.intSnow;
% isOverload=totalWater>Imax1;
% overload = this.intSnow(isOverload) + this.W(isOverload) - Imax1(isOverload);
% intRainFract= this.W(isOverload)./totalWater(isOverload);
% unloadRain=overload.*intRainFract;
% unloadSnow=overload.*(1-intRainFract);
% this.W(isOverload) = this.W(isOverload) - unloadRain;
% this.intSnow(isOverload) = this.intSnow(isOverload) - unloadSnow;
% if ~optDrip
%     this.WThru(isOverload) = this.WThru(isOverload) + unloadRain;
%     this.snowThru(isOverload) = this.snowThru(isOverload) + unloadSnow;
% else
%     this.rainDrip(isOverload) = this.rainDrip(isOverload) + unloadRain;
%     this.snowDrip(isOverload) = this.snowDrip(isOverload) + unloadSnow;
% end
this.hasSnow=this.intSnow>0;
end
function [newDep,newTemp]=MixWater(depth,temp)
%% sum up water of the same phase both massively and thermally
global SMALL
if isempty(depth) && isempty(temp)
    newDep=[];
    newTemp=[];
    return;
end
newDep=sum(depth,2);
noWater=abs(newDep)<SMALL;
newDep(noWater)=0;
newTemp=sum(temp.*depth,2)./newDep;
newTemp(noWater)=temp(noWater,1);
end