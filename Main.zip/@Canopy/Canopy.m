classdef Canopy<Medium
    % This layer only contains cells with a canopy
    properties
       %% vegetation parameter
        index;
        % short wave attenuation factor
        short_atten;
        rad_atten;
        % wind attenuation factor
        wind_atten;
        % wind_h
        wind_h;
        %%%$$(sm^{-1})$ : canopy architectural resistance of evaporation
        rarc;
        %%% $$(sm^{-1}): r_{0c},$  minimum canopy resistance
        r0c;
        %%% RGL:(W/m^2): Value of solar radiation below which will be no transpiration (ranges from 30 W/m^2 for trees to ~100 W/m^2 for crops)
        RGL;
        height;
        %%% trunk ratio
        trunk;
       %% state variables
        WOrg;
        %%%(mm): acccumulated intercepted snow in the vegetation layer
        intSnow;
        intSnowOrg;
        %%%(mm): through snow formulated by forcing at the beginning of the time step 
        snowThru;
        TThruSnow;
        %%%(mm): through rain formulated by forcing at the beginning of the time step 
        snowDrip;
        %%% (mm): rain drips from the canopy formulated at the end of the time step after the energy balance process
        rainDrip;
        %%% R inherited from the base class$$(sm^{-1})$: aerodynamic resistance of the canopy
%         RaC;
%         hasSnow;% intercepted snow depth>0
    end
    methods
        function this=Canopy(index,modelPar)
            global CH_ICE CH_WATER
            nCellsWithCanopy=length(index);
            this=this@Medium(nCellsWithCanopy,CH_WATER,CH_ICE,NaN,NaN,1);
            if this.nCells>0
                this.intSnow=nan(this.nCells,1);
            else
                this.intSnow=[];
            end
            this.index=index;
            this.rarc=[modelPar.covers(this.index).rarc]';
            this.r0c=[modelPar.covers(this.index).rmin]';
            this.RGL=[modelPar.covers(this.index).RGL]';
            this.rad_atten=[modelPar.covers(this.index).rad_atten]';
            this.wind_atten=[modelPar.covers(this.index).wind_atten]';
            this.trunk=[modelPar.covers(this.index).trunk_ratio]';
            %% this may be replaced
            this.wind_h=double([modelPar.covers(this.index).wind_h]');
            this.TWThru=nan(this.nCells,1);
            if this.nCells>0
                this.TThruSnow=nan(this.nCells,1);
                this.snowDrip=zeros(this.nCells,1);
                this.rainDrip=zeros(this.nCells,1);
            else
                this.TThruSnow=[];
                this.snowDrip=[];
                this.rainDrip=[];
            end
        end
        function updateMonthlyParameter(this,date,covers)
            [~,month] = datevec(date);
            covers=covers';
            albedoLib=[covers.albedo];
            albedoLib=albedoLib(month,:)';
            this.albedo=albedoLib(this.index);
            disLib=[covers.displacement];
            disLib=disLib(month,:)';
            this.displacement=disLib(this.index);
            rghLib=[covers.roughness];
            rghLib=rghLib(month,:)';
            this.roughness=rghLib(this.index);
        end
        updateDailyParameter(this,LAI);
        preset(this,forcingVar,isOverstory);
        intercept(this,optBlowSnow,optDrip,TAir,LAI,snowfall,rainfall);
        [shortOverIn,shortUnderIn]=SWPart(this,shortwave);
        dripple(this,dt,TAir,LAI,vaporFlusSub,vaporFluxEvapCanopy,energyPhaseChange,soilSurf);
        [Ra,windAdj]=aerodynamic(this,wind,roughness_surf,n);
        surfaceAeroPar(this,wind_h);
        CleanSmallWater(this);
    end
    methods (Access=private)
        ReadCanopyAttribute(this,strCanopyTable);
    end
    methods (Static)
        error=atmo_energybalance(sensibleHeatAtm,sensibleHeatOver,sensibleHeatUnder);
        [RaC,sensibleHeat,longOverOut,netShort,sensibleHeatAtm]=...
            outwardFluxes(nCells,hasSnow,roughness,adj_displacement,adj_ref_height,...
                  UAdj,RAero,albedo,...
                  TfoliageTemp,TcanopyTemp,airDens,Tair,shortOverIn,shortReflected,...
                  short_atten);
        netRad=netRadiation(this,netShortOver,longOverIn,longOverOut,longUnderOut,grndFlux);
        [AET,actEvapCanopy,actEvapGrnd,actTranspir,vaporFluxSub,latentHeat,PET]=LatentHeat(feedback,dt,nCells,hasSnow,...
             RaC,TfoliageTemp,eActAir,VPD,...
             rainfall,Tair,LAI,elevation,airDens,press,...
             netShortOver,netRadOver,...
             WmCan,WOrgCan,...
             root,Wcr, Wwp,rarc,r0c,RGL,...
             WSoil,iceSoil,SS0,intSnow,W);
         %% canopy energy balance
         [error,energyPhaseChange]=...
              energy_balance(nCells,hasSnow,...
              TfoliageTemp,dt,sensibleHeat,latentHeat,netRad,vaporFluxEvap,vaporFluxSub,...
              CH_positive,CH_negative,...
              intSnow,W,TSurf,TW)
    end
end