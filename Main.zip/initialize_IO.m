function ioLocker = initialize_IO(dirCom,core)
%% initialize the IOLocker
ioLocker=IOLocker(core,dirCom);
end
