classdef ModelParameters <RasterVariables
    % time invariant physical variables
    properties
        nLayers;
        bd;     depthbd; % bulk density
        OM;     depthOM; % organic matter (%w)
        Ksat;   depthKsat; % saturated conductivity (mm/h)
        Wwp;    depthWwp; % wilting point soil moisture (%v)
        FC;     depthFC; % feild capacity (%v)
        Sat;    depthSat % saturated average soil moisture over the grid (%v)
        soilQuartz;soilQuartz0;
        mvRes;   mvRes0;   % minimal residue soil moisture of top layer bare soil
        soilRgh; soilRgh0; % soil roughness (m)
        snowRgh; snowRgh0; % snow roughness (m)
        B0;       B;       % infiltration exponent
        fExcS0;   fExcS;   % multiplier to excS
        fExcI0;   fExcI;   % multiplier to excI
        IM0;      IM;      % impermissivity
        KE0;      KE;      % adjust ratio of PET
        coeM0;    coeM;      
        expM0;    expM;
        coeR0;    coeR;
        coeS0;    coeS;
        delay0;   delay;
%         pExcS10;   pExcS1;
%         pExcS20;   pExcS2;
%         pExcI10;   pExcI1;
%         pExcI20;   pExcI2;
        KS0;      KS;
        KI0;      KI;
        LCC1;% primary land cover classification map
        LCC2;% secondary land cover classfication map
        covers;% cover parameters
        depths;% depths of soil layers
        optSoilThermal;
        evapSurfWater;
        dp;% temperature damp depth
       %% distributed parameters that do not require calibration and has only one layer
        parSUC={'LCC1','LCC2'};
        keyworSUC={'LCC1','LCC2'};
        bPathExtSUC = {'LCC1UseExt','LCC2UseExt'};
        pathExtSUC  = {'LCC1Ext','LCC2Ext'};
       %% parameters that have multiple layers and may need to be calibrated
        typeMC={'BDType','OMType','KsatType','SatType','FCType', 'WwpType'};
        parMC={'bd','OM','Ksat'        ,'Sat',      'FC','Wwp'};
        depthMC={'depthbd','depthOM','depthKsat','depthSat','depthFC','depthWwp'};
        keywordMC={'BD','OM','Ksat'    ,'Sat',      'FC','Wwp'};
        keyword_nLayerMC={'nLayers_BD','nLayers_OM','nLayers_Ksat', 'nLayers_Sat','nLayers_FC','nLayers_Wwp'};
       %% parameters that have only one layer and may need to be calibrated
        parSC      ={'soilQuartz','soilRgh','mvRes',   'B'      ,'IM',...
                      'fExcS','fExcI',...
                      'coeM'             ,'expM'        ,'coeR',...
                      'coeS'             ,'KS'          ,'KI', 'delay',...
                      'snowRgh'};
        keywordTypeSC={'SoilQuartzType','SoilRghType','MvResType','BType'       ,'IMType',...
                       'fExcSType','fExcIType',...
                       'coeMType'    ,'expMType','coeRType',...
                      'coeSType'    ,'KSType'  ,'KIType','delayType',...
                      'snowRghType'};
        keywordSC ={'SoilQuartz','SoilRgh','MvRes',...
                      'B'            ,'IM',...
                      'fExcS','fExcI',...
                      'coeM'         ,'expM'    ,'coeR',...
                      'coeS'         ,'KS'      ,'KI','delay',...
                      'SnowRgh'};
        bPathExtSC = {'SoilQuartzUseExt','SoilRghUseExt','MvResUseExt','BUseExt'      ,'IMUseExt'     ,...
                      'fExcSUseExt','fExcIUseExt',...
                      'coeMUseExt'  ,'expMUseExt' ,...
                      'coeMUseExt'  ,'expMUseExt'   ,'coeRUseExt',...
                      'coeSUseExt'  ,'KSUseExt'     ,'KIUseExt','delayUseExt',...
                      'SnowRghUseExt'};
        pathExtSC  = {'SoilQuartzExt','SoilRghExt','MvResExt','BExt'      ,'IMExt'     ,...
                      'fExcSExt','fExcIExt',...
                      'coeMExt'  ,'expMExt'   ,'coeRExt',...
                      'coeSExt'  ,'KSExt'     ,'KIExt','delayExt',...
                      'SnowRghExt'};
       nModelParSC;% number of single layer model paramters that do not require calibration
       nModelParSUC;% number of single layer model paramters that require calibration
       nModelParMC;% number of multi-layer model parameters that requires calibration
       calibIndices;
      %% calibration related coefficients
       scaleMC;% scaling factors of multi-layer coeffcients 
       scaleSC;% scaling factors of singlye layered coefficients
    end
    properties(Access = private)
%         basinMask;% 
        rows,columns;
        bDistKsat;bDistWM;bDistB;
        bDistIM;bDistcoeM;bDistexpM;bDistcoeR;
        bDistcoeS;bDistKS;bDistKI;
        % Land cover classification
        keywordsLAI={'LAI1','LAI2','LAI3','LAI4','LAI5','LAI6','LAI7','LAI8','LAI9','LAI10','LAI11','LAI12','LAI13'}; 
    end
    methods
        function obj=ModelParameters(pDir,basinMask,geoTransBasic,spatialRefBasic)
            obj=obj@RasterVariables(geoTransBasic,spatialRefBasic);
            obj.basinMask=basinMask;
            pFile=ModelParameters.GenerateFileNames(pDir);
            pDir=[fileparts(pFile),obj.pathSplitor];
            pFileID = fopen(pFile);
            commentSymbol='#';       
            veglibPath=[pDir,ModelParameters.ReadAKeyword(pFileID,'CoverLib',commentSymbol)];
            nClasses=str2double(ModelParameters.ReadAKeyword(pFileID,'NClasses',commentSymbol));
            %% read vegetation/cover parameters
            obj.covers=Cover.ReadVegLib(veglibPath,nClasses);
            %% read soil paramters
            obj.nLayers=str2double(ModelParameters.ReadAKeyword(pFileID,'nLayers',commentSymbol));
            obj.depths=zeros(1,obj.nLayers);
            for l=1:obj.nLayers
                obj.depths(l)=str2double(ModelParameters.ReadAKeyword(pFileID,['depth_',num2str(l)],commentSymbol));
            end
            obj.dp=str2double(ModelParameters.ReadAKeyword(pFileID,'dp',commentSymbol));
            obj.optSoilThermal=ModelParameters.ReadAKeyword(pFileID,'SoilThermal',commentSymbol);
            strEvap=ModelParameters.ReadAKeyword(pFileID,'EvapSurfWater',commentSymbol);
            if strcmpi(strEvap,'yes')
                obj.evapSurfWater=true;
            else
                obj.evapSurfWater=false;
            end
            obj.nModelParSC=length(obj.parSC);
            obj.nModelParMC=length(obj.parMC);
            obj.nModelParSUC=length(obj.parSUC);
            for i=1:obj.nModelParSUC
                cmdInitialize=strcat('obj.',obj.parSUC{i},'=obj.Initialize();');
                cmdFrmGlobal=strcat('[value,bDistr]=ModelParameters.readVarInfo(pFileID,[]',...
                    ',''',obj.keyworSUC{i},''',''',commentSymbol,''',pDir,''',...
                    obj.bPathExtSUC{i},''',''',obj.pathExtSUC{i},''',','obj.geoTrans,obj.spatialRef,obj.basinMask);');
                cmdToVar2=strcat('obj.',obj.parSUC{i},'= ReadRaster(value);');
                eval(cmdInitialize);
                eval(cmdFrmGlobal);
%                 eval(cmdToVar);
                eval(cmdToVar2);
            end
            %% read layered hydraulic properties
            for i=1:obj.nModelParMC 
                % read the number of input layers
                cmdNlayers=['nLayersPar=str2double(ModelParameters.ReadAKeyword(pFileID,''',obj.keyword_nLayerMC{i},''',commentSymbol));'];
                % initialize depths
                cmdInitDepth=['obj.' obj.depthMC{i} '=zeros(nLayersPar,1);'];
                eval(cmdNlayers);
                eval(cmdInitDepth);
                % initialize the parameter
                cmdInitialize=strcat('obj.',obj.parMC{i},'=obj.Initialize(nLayersPar);');
                % original value of the parameters
                eval(cmdInitialize);
                for l=1:nLayersPar
                    cmdFrmGlobal=strcat('[value,bDistr]=ModelParameters.readVarInfo(pFileID,''',...
                    obj.typeMC{i},''',''',obj.keywordMC{i},'_',num2str(l),''',''',commentSymbol,''',pDir,','[],[],',...
                    'obj.geoTrans,obj.spatialRef,obj.basinMask);');
                    cmdToVar2=strcat('if ~bDistr' ,' obj.',obj.parMC{i},...
                       '(:,:,:)= value; else ',' obj.',obj.parMC{i},'(:,:,l)= ReadRaster(value); end');
                    cmdReadDepth=['obj.',obj.depthMC{i},'(',num2str(l),')','=str2double(ModelParameters.ReadAKeyword(pFileID,''',obj.keywordMC{i},'_depth_',num2str(l),''',commentSymbol));'];                    
                    eval(cmdFrmGlobal);
                    eval(cmdToVar2);
                    eval(cmdReadDepth);
                end
            end
            for i=1:obj.nModelParSC
                cmdInitialize=strcat('obj.',obj.parSC{i},'=obj.Initialize();');
                cmdInitialize2=strcat('obj.',obj.parSC{i},'0=obj.Initialize();');
                cmdFrmGlobal=strcat('[value,bDistr]=ModelParameters.readVarInfo(pFileID,''',...
                    obj.keywordTypeSC{i},''',''',obj.keywordSC{i},''',''',commentSymbol,''',pDir,''',...
                    obj.bPathExtSC{i},''',''',obj.pathExtSC{i},''',','obj.geoTrans,obj.spatialRef,obj.basinMask);');
                cmdToVar2=strcat('if ~bDistr' ,' obj.',obj.parSC{i},...
                       '0(obj.basinMask)= value; else ',...
                        ' obj.',obj.parSC{i},'0= ReadRaster(value); end');
                eval(cmdInitialize);
                eval(cmdInitialize2);
                eval(cmdFrmGlobal);
%                 eval(cmdToVar);
                eval(cmdToVar2);
            end
            fclose(pFileID);
            obj.scaleSC=ones(obj.nModelParSC,1);
            obj.scaleMC=ones(obj.nModelParMC,length(obj.depthMC{1}));
%             obj.ModelParReInitialize();
        end
        soilSurf=ModelParReInitialize(this,x0,calibKeywords);
    end
    methods(Static)
        function fileModelPar=GenerateFileNames(parDir)
            fileModelPar=parDir;
        end
    end
end