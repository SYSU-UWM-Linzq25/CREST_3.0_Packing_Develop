function bValue=yesno2boolean(value)
    if strcmpi(value,'yes')
       bValue=true;
   else
       bValue=false;
   end
end