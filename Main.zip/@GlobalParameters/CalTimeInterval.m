function interval=CalTimeInterval(str,fmt,splitor)
%% 2) updated by Shen, X. on June 27, 2019
yearInd=strfind(fmt,'yyyy');
doyInd=[strfind(fmt,'DOY'),strfind(fmt,'doy')];
if ~isempty(yearInd) && ~isempty(doyInd)
    yearInd=yearInd(1);
    year=str2double(str(yearInd:yearInd+3));
    date0=year*365;
    doyInd=doyInd(1);
    try
        doy=str2double(str(doyInd:doyInd+2));
    catch
        try
            doy=str2double(str(doyInd:doyInd+1));
        catch
            doy=str2double(str(doyInd));
        end
    end
    interval=date0+doy;
end
strContent=strsplit(str,splitor);
str=strContent{end};
fmtContent=strsplit(fmt,splitor);
fmt=fmtContent{end};
yInd=strfind(fmt,'y');
if ~isempty(yInd)
    fmt=fmt(yInd(1):end);% modified
    str=str(yInd(1):end);% modified
%% start 2)
%     return; % modified
end
LInd=strfind(fmt,'LL');
LInd2=strfind(fmt,'LLUU');

lead=0;
if (~isempty(LInd2)) || (~isempty(LInd))
    if ~isempty(LInd2)
        formatL='yyyymmddHHMM';
        strL=['19910101',str(LInd2(1):LInd2(1)+3)];
        for i=1:length(LInd2)
            str(LInd2(i):LInd2(i)+3)='LLUU';
        end
    elseif ~isempty(LInd)
        formatL='yyyymmddHH';
        strL=['19910101',str(LInd(1):LInd(1)+1)];
        for i=1:length(LInd)
            str(LInd(i):LInd(i)+1)='LL';
        end
    end
    lead=datenum(strL,formatL)-datenum(1991,1,1);
end
%% end 2)
try
    strOrg='';
    fmtOrg='';
    strVal='';
    for i=1:length(fmt)
        number=str2double(str(i));
        if ~isnan(number) && isnan(str2double(fmt(i)))
            strOrg=strcat(strOrg,'0');
            fmtOrg=strcat(fmtOrg,fmt(i));
            strVal=strcat(strVal,str(i));
%         else
%             strOrg=strcat(strOrg,str(i));
        end
    end
%     timeOrg=datenum(strOrg,fmt);
    timeOrg=datenum(strOrg,fmtOrg);
%     time=datenum(str,fmt);
    time=datenum(strVal,fmtOrg);
    interval=time-timeOrg+lead;
catch
end
end