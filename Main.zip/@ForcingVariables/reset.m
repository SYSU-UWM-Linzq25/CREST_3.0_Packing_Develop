 function bEnd=reset(this,mode,taskType,isMoveBack,core,nCores)
%% update history
% updated in Sept. 16, 2019, if nCores> number of days
% updated in Mar. 02, 2017 intermittant event mode added back
% updated in Feb. 23, 2016 to have new partition of the time span
global SECONDS_PER_DAY
bEnd=false;
% if exist('isReload','var') && isReload && strcmpi(taskType,'Routing')
this.iPeriod=this.iPeriod+1;
% else
%     this.iPeriod=1;
% end
if this.iPeriod>this.nPeriod && strcmpi(taskType,'Routing')
    bEnd=true;
    this.iPeriod=0;
    return;
end
% this.iPeriod=1;
%% if runs using multi-core, partition the dates
dateStartOrg=this.dateStart;
if ~isempty(this.dateStartCoarse) && (this.dateStart>this.dateStartCoarse || this.dateEnd<this.dateEndCoarse)
    error ('insufficient time span of land surface simulation')
end
if (strcmpi(taskType,'ImportForc') || strcmpi(taskType,'Mosaic') || strcmpi(taskType,'DeepHydro_regrid')) && (~isMoveBack)%% calculate the period for a given node
    nTimeSteps=round((this.dateEnd-this.dateStart+this.timeStep)/this.timeStep);
%     perTimeSteps=ceil(nTimeSteps/nCores);
    datesReal=(round(this.dateStart*SECONDS_PER_DAY)+((0:nTimeSteps-1)'*round(SECONDS_PER_DAY*this.timeStep)))/SECONDS_PER_DAY;
    dnFile=datenum(datestr(datesReal,this.fmtSubDir),this.fmtSubDir);
    ufile=unique(dnFile);
    perFiles=ceil(length(ufile)/nCores);
    ifileStart=perFiles*(core-1)+1;
%% bug removed
    ifileStart0=ifileStart;
    if ifileStart>length(ufile)
        ifileStart=length(ufile);
        ifileEnd=1;
    else
        ifileEnd=min([length(ufile),ifileStart+perFiles-1]);
    end
    fileDateStart=ufile(ifileStart);
    fileDateEnd=ufile(ifileEnd);
    indexStart=find(dnFile==fileDateStart,1,'first');
    indexEnd=find(dnFile==fileDateEnd,1,'last');
    this.dateStart=datesReal(indexStart);
    this.dateEnd=datesReal(indexEnd);
    if ifileStart0>length(ufile)
        this.dateStart=this.dateEnd+1;
    end
    if this.dateStart<=this.dateEnd
        disp(['running time:',datestr(this.dateStart),'-',datestr(this.dateEnd)]);
    else
        bEnd=true;
        disp('this core is not going to be used...');
        return;
    end
        
%     this.dateStart=min(ForcingVariables.addDatenum(this.dateStart,(core-1)*perTimeSteps*this.timeStep),...
%         this.dateEnd);
%     this.dateEnd=min(ForcingVariables.addDatenum(this.dateStart,(perTimeSteps-1)*this.timeStep),...
%         this.dateEnd);
end
%% reset the date
this.dateCur=this.dateStart(this.iPeriod);
if strcmpi(taskType,'Routing') ||strcmpi(taskType,'Mosaic') || strcmpi(taskType,'DeepHydro_regrid')
    moveOnly=true;
else
    moveOnly=false;
end
if ~moveOnly% if mosaic or routing, no forcing data are really needed
    this.dateLAISto=ForcingVariables.addDatenum(...
         ForcingVariables.FindFirstForc(NaN,...% There is no forecast of LAI
            this.dateStart,this.timeStep,this.dateIntervalLAI,...
            this.fmtLAI,this.dateConvLAI,this.dirExtLAI,this.extLAI,this.pathSplitor),...
         -this.dateIntervalLAI);% No forecast LAI existsm therefore, the runstyle is always false
    this.datePrecSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalPrec,...
        this.fmtPrec,this.dateConvPrec,this.dirExtPrec,this.extPrec,this.pathSplitor),...
        -this.dateIntervalPrec);
    this.dateSWSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalSW,...
        this.fmtSW,this.dateConvSW,this.dirExtSW,this.extSW,this.pathSplitor),...
        -this.dateIntervalSW);
    this.dateLWSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalLW,...
        this.fmtLW,this.dateConvLW,this.dirExtLW,this.extLW,this.pathSplitor),...
        -this.dateIntervalLW);
    this.dateTairSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalTair,...
        this.fmtTair,this.dateConvTair,this.dirExtTair,this.extTair,this.pathSplitor),...
        -this.dateIntervalTair);
%     this.dateTairSto=this.dateTair0-this.dateIntervalTair;
    this.dateHUSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalHU,...
        this.fmtHU,this.dateConvHU,this.dirExtHU,this.extHU,this.pathSplitor),...
        -this.dateIntervalHU);
     this.datePresSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalPres,...
        this.fmtPres,this.dateConvPres,this.dirExtPres,this.extPres,this.pathSplitor),...
        -this.dateIntervalPres);
    if strcmpi(this.typeWind,'UV')
        this.dateWindUSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalWindU,...
        this.fmtWindU,this.dateConvWindU,this.dirExtWindU,this.extWindU,this.pathSplitor),...
        -this.dateIntervalWindU);
        this.dateWindVSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalWindV,...
        this.fmtWindV,this.dateConvWindV,this.dirExtWindV,this.extWindV,this.pathSplitor),...
        -this.dateIntervalWindV);
    else
        this.dateWindSto=ForcingVariables.addDatenum(...
        ForcingVariables.FindFirstForc(this.dateStartFore,...
        this.dateStart,this.timeStep,this.dateIntervalWind,...
        this.fmtWind,this.dateConvWind,this.dirExtWind,this.extWind,this.pathSplitor),...
        -this.dateIntervalWind);
    end
        
    bSuc=this.ReadIntForcing(mode,taskType,core,nCores);
    if ~bSuc
        this.dateStart=ForcingVariables.addDatenum(this.dateStart,-this.timeStep);
        this.reset(mode,taskType,true,cores,nCores);
    end
end
% if this.timeStepCoarse>this.timeStep% two time lines exist
if this.isMosaic
    if this.timeStepCoarse>this.timeStep
        disp('two time lines')
    elseif this.timeStepCoarse==this.timeStep
        disp('one time line')
    else
        error('cannot disaggregate to a finer temporal resolution');
    end
    this.setToFirstCoarse(dateStartOrg);
%     disp(datestr(this.dateCur));
%     disp(datestr(this.dateCurCoarse));
    this.nAgger=1;
end
end
