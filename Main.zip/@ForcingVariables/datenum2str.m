function forcNameExt=datenum2str(date,fmtForc,pathSplitor,date0)
%% update history
% 2) add forecast capability
%% convert the offset date nubmer to string
% copy the format to the filename
forcNameExt=fmtForc;
% get the format and after the last '\'
fmtContent=strsplit(fmtForc,pathSplitor);
%% begin 2
fmtEnd=fmtContent{end};
interval=datenum(1991,1,1,1,0,0)-datenum(1991,1,1);
intervalM=datenum(1991,1,1,0,1,0)-datenum(1991,1,1);
foreIndM=[strfind(fmtEnd,'LLUU'),strfind(fmtEnd,'lluu')];
foreInd=[strfind(fmtEnd,'LL'),strfind(fmtEnd,'ll')];
if ~isempty(foreInd)
    lead=round((date-date0)/interval);
    date=date0;
elseif ~isempty(foreIndM)
    leadH=floor((date-date0)/interval);
    leadM=round((date-date0-leadH*interval)/intervalM);
    lead=leadH*100+leadM;
    date=date0;
end
%% end 2
yInd=strfind(fmtEnd,'y');
if ~isempty(yInd)
    try
        fmtEnd=fmtEnd(yInd(1):end);
        NameEnd=datestr(date,fmtEnd);
        slashInd=strfind(fmtForc,pathSplitor);
        if ~isempty(slashInd)
            slashInd=slashInd(end);
        else
            slashInd=0;
        end
        forcNameExt(slashInd+yInd(1):end)=NameEnd;
    catch
    end
end
% previous string
[year, mon,day,~,~,~] = datevec(date);
doy=datenum(year,mon,day)-datenum(year,1,1)+1;
strDOY=sprintf('%03d',doy);
strdoy=num2str(doy);
yearInd=[strfind(forcNameExt,'yyyy'),strfind(forcNameExt,'YYYY')];
for i=1:length(yearInd)
    forcNameExt(yearInd(i):yearInd(i)+3)=datestr(date,'yyyy');
end
monInd=strfind(forcNameExt,'mm');
monInd3=strfind(forcNameExt,'mmm');
for i=1:length(monInd)
    forcNameExt(monInd(i):monInd(i)+1)=datestr(date,'mm');
end
for i=1:length(monInd3)
    forcNameExt(monInd3(i):monInd3(i)+2)=datestr(date,'mmm');
end
dayInd=strfind(forcNameExt,'dd');
for i=1:length(dayInd)
    forcNameExt(dayInd(i):dayInd(i)+1)=datestr(date,'dd');
end
hourInd=strfind(forcNameExt,'HH');
for i=1:length(hourInd)
    forcNameExt(hourInd(i):hourInd(i)+1)=datestr(date,'HH');
end
minInd=strfind(forcNameExt,'MM');
for i=1:length(minInd)
    forcNameExt(minInd(i):minInd(i)+1)=datestr(date,'MM');
end
secInd=strfind(forcNameExt,'SS');
for i=1:length(secInd)
    forcNameExt(secInd(i):secInd(i)+1)=datestr(date,'SS');
end
if ~isempty(foreIndM)
    foreIndM=[strfind(forcNameExt,'LLUU'),strfind(fmtEnd,'lluu')];
    for i=1:length(foreIndM)
        forcNameExt(foreInd(i):foreInd(i)+1)=sprintf('%04d',lead);
    end
elseif ~isempty(foreInd)
    foreInd=[strfind(forcNameExt,'LL'),strfind(fmtEnd,'ll')];
    for i=1:length(foreInd)
        forcNameExt(foreInd(i):foreInd(i)+1)=sprintf('%02d',lead);
    end
end
%% if doy is little, there is no left zero pads 
doyIndLittle=strfind(fmtForc,'doy');
%% otherwise, 1 is 001
doyIndCap=strfind(fmtForc,'DOY');

for i=1:length(doyIndCap)
    forcNameExt(doyIndCap(i):doyIndCap(i)+2)=strDOY;
end
for i=length(doyIndLittle):-1:1
    forcNameExt(doyIndLittle(i):doyIndLittle(i)+length(strdoy)-1)=strdoy;
    forcNameExt(doyIndLittle(i)+length(strdoy):doyIndLittle(i)+2)='';
end
end