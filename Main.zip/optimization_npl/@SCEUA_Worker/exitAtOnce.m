function exitAtOnce(this)
this.checkThePool();
this.checkLocStartPerm();
this.reportLocalFinish();
this.finalize();
end