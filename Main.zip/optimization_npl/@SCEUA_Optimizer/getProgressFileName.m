function fileName=getProgressFileName(this)
fileName=[this.statusFolder,this.statusName,'.sta'];
end