classdef SCEUA_Optimizer<Optimizer
    properties(Access=private)
        % Definition:
        %  x0 = the initial parameter array at the start;
        %     = the optimized parameter array at the end;
        %  f0 = the objective function value corresponding to the initial parameters
        %     = the objective function value corresponding to the optimized parameters
        %  bl = the lower bound of the parameters
        %  bu = the upper bound of the parameters
        %  iseed = the random seed number (for repetetive testing purpose)
        %  iniflg = flag for initial parameter array (=1, included it in initial
        %           population; otherwise, not included)
        %  nGroup = number of complexes (sub-populations)
        %  npg = number of members in a complex 
        %  nps = number of members in a simplex
        %  nspl = number of evolution steps for each complex before shuffling
        %  mings = minimum number of complexes required during the optimization process
        %  maxn = maximum number of function evaluations allowed during optimization
        %  kstop = maximum number of evolution loops before convergency
        %  percento = the percentage change allowed in kstop loops before convergency
        nGroup;        % number of complexes (sub-populations)
        iseed=-1;   % the random seed number (for repetetive testing purpose)
        iniflg=1;   % flag for initial parameter array (=1, included it in initial
        % population; otherwise, not included)
        maxn=2000;    % maximum number of function evaluations allowed during optimization
        kstop=10;      % maximum number of evolution loops before convergency
        percento=1e-4;   % the percentage change allowed in kstop loops before convergency
        peps=1e-3;     % predescribed distance of ending an evolution.
        STCD;
        nParal;
        comFolder;
        statusFolder;
        fmt='%6d: %8.4f  %6d ';
        lsWorkers; % a list of worker(core) occupation. The row number stands for the core# the element value stands for the simulation#
        
        fileNameHead='worker_';
        statusName='completed';
        fileExitHead='exit';
        fileExit;
    end
    properties
        keywordsAct;
    end
    properties(Constant)
        keywordsVar ={'fExcS', 'fExcI' ,'Ksat'    ,'WM',...
                      'B'            ,'IM'      ,'KE',...
                      'coeM'         ,'expM'    ,'coeR',...
                      'coeS'         ,'KS'      ,'KI','delay'};
        keywordsN={'NCalibStations','Name'};
        keywordsSEA_UA={'iseed','ngs','maxn','kstop','pcento'}
    end
    methods (Access=private)
        fileRes=genResName(this,core,isEV);
        parFileName=genParName(obj,core,isEV);
        grantPermission(obj,Slot,i,xTemp);
        grantEvolvePermission(obj,nspl,npg,nps,cf,cx,igs,core);
        [freeCore,resGen]=getOneSlot(this,isEV);
        ixf=readRes(obj,core);
        [icf,icx]=readEvolveRes(this,core,nspl);
        finalizeEvolve(obj,ic);
        % display
        SCE_UA_Dislay(this,nloop,nTrial,bestf,bestx,worstf,worstx);
        % fileNames
        fileName=getProgressFileName(this);
        
        % status functions
        [evNum,x,f,criter]=readProg(this,nPar);
        writeProg(this,evNum,x,f,criter);
    end
    methods
        function obj=SCEUA_Optimizer(calibPath,resPath,outSTCD,nP,comFolder,statusFolder)
            calibFile=strcat(calibPath,'calibrations.txt');
            logfile=SCEUA_Optimizer.GenLogFileName(resPath,outSTCD);
            commentSym='#';           
          %% get the number of sites
            ns=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsN{1},commentSym);
            minVal=zeros(length(SCEUA_Optimizer.keywordsVar),ns);
            initVal=zeros(length(SCEUA_Optimizer.keywordsVar),ns);
            maxVal=zeros(length(SCEUA_Optimizer.keywordsVar),ns);
            stcd=zeros(ns,1);
            for s=1:ns
                stcd(s)=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsN{2},commentSym);
                for i=1:length(SCEUA_Optimizer.keywordsVar)
                    [minVal(i,s),initVal(i,s),maxVal(i,s)]=SCEUA_Optimizer.readVarInfo(calibFile,...
                        strcat(SCEUA_Optimizer.keywordsVar{i},'_',num2str(s)),commentSym);
                end
            end
            index=minVal==-1;
            minVal(index)=[];
            initVal(index)=[];
            maxVal(index)=[];
            minVal=minVal(:).';maxVal=maxVal(:).';initVal=initVal(:).';
            obj=obj@Optimizer(logfile,minVal,maxVal,initVal);
            obj.fileExit=[statusFolder,obj.fileExitHead,'.sta'];
            obj.keywordsAct=SCEUA_Optimizer.keywordsVar(~index);
            %obj.simObj=so;
            obj.nParal=nP;
            obj.comFolder=comFolder;
            obj.statusFolder=statusFolder;
            obj.STCD=stcd;
            %initial the work list
            obj.lsWorkers=-1*ones(obj.nParal,1);
            obj.iseed=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsSEA_UA{1},commentSym);
            obj.nGroup=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsSEA_UA{2},commentSym);
            obj.maxn=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsSEA_UA{3},commentSym);
            obj.kstop=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsSEA_UA{4},commentSym);
            obj.percento=SCEUA_Optimizer.readSingleVar(calibFile,SCEUA_Optimizer.keywordsSEA_UA{5},commentSym);
        end
        [bestx,bestf,BESTX,BESTF] = sceuaMultiTask(obj);
        function optimize(obj,comType)
            switch comType
                case 'par'
                    obj.optimizeMultiTask();
                case 'seq'
                    obj.optimizeSeq();
            end
        end
        function optimizeMultiTask(obj)
            obj.LogHead();
            obj.sceuaMultiTask();
        end 
        function optimizeSeq(obj)
        		obj.LogHead();
            [obj.optX,obj.optF]=sceua_seq(obj.x0,obj.lBound,obj.uBound,...
                   obj.maxn,obj.kstop,obj.percento,obj.peps,obj.nGroup,...
                   obj.iseed,obj.iniflg,@obj.functionWrapperSeq,obj.funcHandle,obj.logFile);
        end
        
        function exportRes(obj,paramPath)
            [NewParamfilepath,~,extenname] = fileparts(obj.logFile);pathSplitor='/';
            NewParamfilepath=strcat(NewParamfilepath,pathSplitor);
            NewParamfilenameFinal=strcat(NewParamfilepath,'DoneCaliParameters',extenname);
            bestXvecor=obj.optX;
            copyfile(paramPath,NewParamfilenameFinal,'f')
            
            gfilepath=NewParamfilenameFinal;
            keyword=obj.keywordsAct;
            writevalue=bestXvecor;
            commentSymbol='#';
            Newfilepath=gfilepath;

            gfileID=fopen(gfilepath);
            iter=0;
            while ~feof(gfileID)
                tline= fgetl(gfileID);
                iter=iter+1; 
                Newtline{iter}=tline;    
             try
                if strcmp(tline(1),commentSymbol)==1        
                else
                    strArr = regexp(tline,commentSymbol,'split');
                    strContent=strArr{1};
                    strValue=regexp(strContent,'=','split');
                    strContent=strtrim(strValue{1});
                    for ii=1:length(keyword)
                            thiskeyword=keyword{ii};
                            thisRatio=writevalue(ii);
                            if strcmpi(strContent,thiskeyword)
                                    thisPar0muiltiplyRatio=thisRatio*str2double(strValue{2});
                                    Newtline{iter}=strrep(tline,strValue{2},num2str(thisPar0muiltiplyRatio));                                    
                            end
                    end
                 end
             catch
                        
             end
                
            end
            fclose(gfileID);
            fidin1=fopen(Newfilepath,'w+');
            for j=1:1:iter
            fprintf(fidin1,'%s\n',Newtline{j});
            end
            fclose(fidin1);         
        LogHead(obj);
        end
    end

    methods (Static)
        function fileName=GenLogFileName(resPath,outSTCD)
            fileName=strcat(resPath,outSTCD,'calib_log.txt');
        end
        function [minVal,initVal,maxVal]=readVarInfo(calibFile,keywordVar,commentSymbol)
            cFileID = fopen(calibFile);
            tline = fgetl(cFileID);
            minVal=-1;
            initVal=-1;
            maxVal=-1;
            while tline~=-1
                if strcmp(tline(1),commentSymbol)==1
                    tline = fgetl(cFileID);
                    continue;
                end
                strArr = regexp(tline,commentSymbol,'split');
                strContent=strArr{1};
                strContent=strtrim(strContent);
                if ~isempty(strfind(strContent, keywordVar))
                    strValue=regexp(strContent,'=','split');
                    strValue=regexp(strValue{2},'\t\t','split');
                    strValue{1}=regexprep(strValue{1},' ','');
                    strValue{2}=regexprep(strValue{2},'\t','');
                    strValue{2}=regexprep(strValue{2},' ','');
                    strValue{3}=regexprep(strValue{3},'\t','');
                    strValue{3}=regexprep(strValue{3},' ','');
                    minVal=str2double(strValue{1});
                    initVal=str2double(strValue{2});
                    maxVal=str2double(strValue{3});
                    break;
                end
                tline = fgetl(cFileID);
            end
            fclose(cFileID);
        end
        function value=readSingleVar(calibFile,keyword,commentSymbol)
            cFileID = fopen(calibFile);
            tline = fgetl(cFileID);
            while tline~=-1
                 if strcmp(tline(1),commentSymbol)==1
                     tline = fgetl(cFileID);
                     continue;
                 end
                 strArr = regexp(tline,commentSymbol,'split');
                 strContent=strArr{1};
                 strContent=strtrim(strContent);
                 if ~isempty(strfind(strContent, keyword))                     
                     strValue=regexp(strContent,'=','split');
                     strValue{2}=regexprep(strValue{2},'\t','');
                     value=str2double(strValue{2});
                     break;
                 end
                 tline = fgetl(cFileID);
            end
        end
    end
end