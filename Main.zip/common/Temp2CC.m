function CC=Temp2CC(T,swq,CH)
global m2mm
CC=T.*swq/m2mm*CH;
end