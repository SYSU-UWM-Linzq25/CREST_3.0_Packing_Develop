function T=CC2Temp(CC,swq,CH)
global m2mm
T=CC*m2mm./(swq*CH);
end